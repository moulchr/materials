# Deployment Hands-on

[Instructions for 16w20 Hands-On Deployment exercises](DeploymentHandsOn.md)

[Link to GEL add-on playbook for 16w20](add-on)

