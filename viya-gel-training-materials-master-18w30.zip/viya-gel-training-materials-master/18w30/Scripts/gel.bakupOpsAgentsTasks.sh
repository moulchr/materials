#!/bin/bash
#
# Backup Operations Infrastructure agent tasks
#

# Set default variables
_SASDELPOYMENTROOT=/opt/sas
_SASDELPOYMENTID=viya
_SASVIYAHOME=${_SASDELPOYMENTROOT}/${_SASDELPOYMENTID}/home

# Create timstamp variable
_TIMESTAMP=$(date "+%Y%m%d-%H%M")
echo $_TIMESTAMP

# Create backup directory if does not exist
mkdir -p ~/BackupOpsAgentsTasks

# Backup ops-agent and ops-agentsrv tasks
cd ${_SASVIYAHOME}/bin
./sas-ops-agent export -name ops-agent -tasks ~/BackupOpsAgentsTasks/ops-agent_backupTasks_${_TIMESTAMP}.json
./sas-ops-agent export -name ops-agentsrv -tasks ~/BackupOpsAgentsTasks/ops-agentsrv_backupTasks_${_TIMESTAMP}.json

