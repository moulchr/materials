#!/bin/bash
#
# GEL Coordinated Startup for Viya33 across multiple hosts
# -------------------------------------------------------------------
# This script is written specifically to the Viya33 collection of 
# 4 hosts plus 1 SMP CAS used for the admin track:
# - sasviya01.race.sas.com - primary Consul, Vault, pg, and more
# - sasviya02.race.sas.com - primary CacheLocator and more
# - sasviya03.race.sas.com - more services
# - sasviya04.race.sas.com - more services
# - sascas01.race.sas.com  - SMP CAS
#
# There exist some strong dependencies between Viya services on 
# sasviya01 and 02 - in both directions. So coordinating the startup.
# http://sww.sas.com/cgi-bin/quick_browse?defectid=S1398667
#
# Stopping is easy compared to start. 
# -------------------------------------------------------------------
# rocoll - JAN-2018                          SAS... The Power to Know
# cangxc - MAY 2018 Call gel.*-viya33.yml scripts
#


echo
echo ">>>GEL>>> Starting Viya 3.3 services across 5 hosts"
echo "          Allow ~20 to 25 min for completion - esp. on sasviya03,04"
echo "          Begin: `date`"
echo "          ----------------------------------------------------------------"

cd /root/sas_viya_playbook

/usr/bin/ansible-playbook gel.start-viya33.yml

echo
echo ">>>GEL>>> Done."
echo "          End: `date`"
echo "          ----------------------------------------------------------------"
exit
