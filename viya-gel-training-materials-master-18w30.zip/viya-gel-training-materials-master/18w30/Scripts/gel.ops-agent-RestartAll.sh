#!/bin/bash
#
# Restart all ops-agent* services in the Viya deployment
#

SYSTEM_TYPE=$(ps -p 1 | grep -v PID | awk '{ print $4 }')

cd /root/sas_viya_playbook/
if [[ "${SYSTEM_TYPE}" == "systemd" ]]
   then
      # systemd - ops-agent
      echo "Restart sas-viya-ops-agent-default on all Viya deployment hosts"
      echo "---------------------------------------------------------------"
      ansible sas-all -m shell -a 'systemctl restart sas-viya-ops-agent-default'
      
      # systemd - ops-agentsrv
      echo "Restart sas-viya-ops-agentsrv-default on the Viya operations host"
      echo "-----------------------------------------------------------------"
      ansible Operations -m shell -a 'systemctl restart sas-viya-ops-agentsrv-default'
   else
      # SysV - ops-agent
      echo "Restart sas-viya-ops-agent-default on all Viya deployment hosts"
      echo "---------------------------------------------------------------"
      ansible sas-all -m shell -a 'service sas-viya-ops-agent-default restart'
      
      # SysV - ops-agentsrv
      echo "Restart sas-viya-ops-agentsrv-default on the Viya operations host"
      echo "-----------------------------------------------------------------"
      ansible Operations -m shell -a 'service sas-viya-ops-agentsrv-default restart'
fi
