#!/bin/sh
# Create Environment Variables
myHostsStart=("intcas01" "intcas02" "intcas04") # On this collection, backupAgent only on this host (intviya01), intcas01, intcas02 and potentialy on intcas04.
# Ensure list is reverse order
myHostsStop=("intcas04" "intcas03" "intcas02" "intcas01")
NFShost="intviya01"
NFSdir="/BackupCentral"
NFSmnt="/BackupCentral"

case "$1" in
   'start')
      # Export file system
      systemctl start nfs
      echo "Creating filesystem to export"
      mkdir -p ${NFSdir}
      chmod 777 ${NFSdir}
      echo "Exporting filesystem ${NFSdir}"
      /usr/sbin/exportfs -i -o rw,sync,no_root_squash :${NFSdir}
      for host in ${myHostsStart[*]}; 
         do
            # Make sure directory exists
            /usr/bin/ssh ${host} -C "mkdir -p ${NFSmnt}"
            # Unmount directory
            /usr/bin/ssh ${host} -C "/usr/bin/umount -l -f ${NFSmnt}"
            # Mount directory
            echo "Mounting directory ${NFSmnt} on ${host}"
            /usr/bin/ssh ${host} -C "/usr/bin/mount -o vers=4,nfsvers=4 -t nfs ${NFShost}:${NFSdir} ${NFSmnt} -o \"rw,defaults\""
         done
      ;;
   'stop')
      for host in ${myHostsStop[*]};
         do
            # Unmount directory
            echo "Un-mounting directory ${NFSmnt} on ${host}"
            /usr/bin/ssh ${host} -C "/usr/bin/umount -l -f ${NFSmnt}"
            done
      echo "Removing export for filesystem ${NFSdir}"
      systemctl stop nfs
      ;;
   'cleanup')
      for host in ${myHostsStop[*]}; 
         do
            # Remove directory
            echo "Remove directory ${NFSmnt} on ${host}"
            /usr/bin/ssh ${host} -C "/usr/bin/umount -l -f ${NFSmnt}"
            /usr/bin/ssh ${host} -C "/usr/bin/rm -rf ${NFSmnt}"
         done
      # echo "Removing directory ${NFSdir}"
      # /usr/bin/rm -rf ${NFSdir}
      ;;
   *)
      echo "Usage: gel_nfs-CASControllers.sh {start|stop|cleanup}"
      exit 1
      ;;
esac
