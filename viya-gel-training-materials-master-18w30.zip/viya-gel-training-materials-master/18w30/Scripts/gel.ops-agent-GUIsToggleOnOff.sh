#!/bin/bash
#
# Toggle On/Off the ops-agent* GUI
#
cd /root/sas_viya_playbook/

# ops-agent
echo "Toggle on/off ops-agent GUI on all Viya deployment hosts"
echo "--------------------------------------------------------"
ansible sas-all -m shell -a "PID=\$(ps -edf | grep -v 'root' | grep ops-agent | grep sas | grep -v 'name' | awk '{ print \$2 }'); kill -usr1 \${PID}"

# ops-agentsrv
echo "Toggle on/off ops-agentsrv GUI on the Viya operations host"
echo "----------------------------------------------------------"
ansible Operations -m shell -a "PID=\$(ps -edf | grep -v 'root' | grep ops-agent | grep sas | grep 'name' | awk '{ print \$2 }'); kill -usr1 \${PID}"

