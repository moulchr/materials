#!/bin/bash
#
# Cleanup undesired services in SAS Configuration server (Consul)
#

SYSTEM_TYPE=$(ps -p 1 | grep -v PID | awk '{ print $4 }')

echo "Cleanup the SAS Configuration server (Consul) - Delete duplicate or bad entries"
echo "-------------------------------------------------------------------------------"
cd /root/sas_viya_playbook/

echo "     1- Stop all Viya deployment services on all hosts"
echo "     -------------------------------------------------"
ansible-playbook gel.stop-viya33.yml

echo "     2- Load the last version of the GEL Consul cleanup script"
echo "     ---------------------------------------------------------"
ansible sas-all -m shell -a "cp -p /mnt/workshop_files/workshop_content/Utils/root_viya01/gel.ListCleanupExistingConsulRegisteredServices.sh /root/gel.ListCleanupExistingConsulRegisteredServices.sh; chmod 744 /root/gel.ListCleanupExistingConsulRegisteredServices.sh"

echo "     3 -Start the SAS Configuration server and all agents (Consul)"
echo "     -------------------------------------------------------------"
if [[ "${SYSTEM_TYPE}" == "systemd" ]]
   then
      ansible sas-all -m shell -a 'systemctl start sas-viya-consul-default'
   else
      ansible sas-all -m shell -a 'service sas-viya-consul-default start'
fi

echo "     4 -Cleanup the residual registered services againts the SAS Configuration server (Consul), except the reserved registered services - Against all Viya deployment hosts"
echo "     ----------------------------------------------------------------------------------------------------------------------------------------------------------------------"
ansible sas-all -m shell -a '/root/gel.ListCleanupExistingConsulRegisteredServices.sh -l -c'

echo "     5- List the content of the cleaned SAS Configuration server (Consul)"
echo "     --------------------------------------------------------------------"
ansible sas-all -m shell -a '/root/gel.ListCleanupExistingConsulRegisteredServices.sh -l'

echo "     6 -Stop the SAS Configuration server and all agents (Consul)"
echo "     ------------------------------------------------------------"
if [[ "${SYSTEM_TYPE}" == "systemd" ]]
   then
      ansible sas-all -m shell -a 'systemctl stop sas-viya-consul-default'
   else
      ansible sas-all -m shell -a 'service sas-viya-consul-default stop'
fi

echo "     7- Start all Viya deployment services on all hosts"
echo "     --------------------------------------------------"
ansible-playbook gel.start-viya33.yml
