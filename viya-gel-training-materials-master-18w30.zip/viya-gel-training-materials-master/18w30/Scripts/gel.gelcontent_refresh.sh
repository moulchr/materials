cd /
/bin/rm -rf /gelcontent/*
tar -xpvzf /root/admin/osfolders_data/workshop_gelcontent.tar.gz