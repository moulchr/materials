# Viya 3.4, portable edition  

- [Viya 3.4, portable edition](#viya-34-portable-edition)
    - [Overall steps](#overall-steps)
    - [Typical deployment prep tasks](#typical-deployment-prep-tasks)
        - [Pre-req tasks](#pre-req-tasks)
        - [Get the .zip file onto the instance](#get-the-zip-file-onto-the-instance)
        - [Get Mirror Manager onto the instance](#get-mirror-manager-onto-the-instance)
        - [Download the mirror](#download-the-mirror)
        - [Get the Orchestration CLI](#get-the-orchestration-cli)
        - [Build your playbook](#build-your-playbook)
        - [Perform the pre-reqs with VIRK](#perform-the-pre-reqs-with-virk)
    - [Setting a very static hostname and IP at the linux level](#setting-a-very-static-hostname-and-ip-at-the-linux-level)
        - [Change the hostname](#change-the-hostname)
        - [Associate your hostname with the 127.0.0.1 ip](#associate-your-hostname-with-the-127001-ip)
        - [Reboot and check](#reboot-and-check)
    - [Deploy OpenLDAP](#deploy-openldap)
    - [Edit the deployTarget reference in your inventory](#edit-the-deploytarget-reference-in-your-inventory)
    - [Kick off the deployment](#kick-off-the-deployment)

## Overall steps

1. get a RHEL 7 instance on AWS
1. Perform the prep tasks
1. set it up to have a static, hard-coded hostname and IP
1. deploy OpenLDAP on it
1. add special overrides to the inventory
1. deploy Viya SMP

## Typical deployment prep tasks

### Pre-req tasks

1. Install EPEL on RHEL7

    ```bash
    sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm

    ```

1. Install Ansible and a few important packages

    ```bash
    sudo yum install python-pip git java-1.8.0-openjdk-devel tmux -y
    sudo pip install ansible

    ```

1. Setup the SAS DNS (because we are on AWS, with a Site-to-site VPN to Cary)

    ```bash
    ## get that playbook
    ansible localhost -m get_url \
       -a "url=https://10.24.8.146/cloudup/viya-gel-training-materials/raw/master/18w30/gel.example.playbooks/gel.enable.sas.dns.on.AWS.federated.yml \
      dest=./gel.enable.sas.dns.on.AWS.federated.yml \
      validate_certs=no \
      mode=0664 "

    ## run the playbook to update the DNS information
    ansible-playbook ./gel.enable.sas.dns.on.AWS.federated.yml --diff
    ```

### Get the .zip file onto the instance

1. Download the SOE zip file

    ```bash
    ## I'm cheating because I'm on the SAS network
    ## normally you'd upload your .zip file to the server
    ORDERNUM=09NC8R
    ansible localhost \
        -m get_url \
        -a "url=http://spsrest.fyi.sas.com:8081/comsat/orders/$ORDERNUM/view/soe/SAS_Viya_deployment_data.zip \
            dest=./SAS_Viya_deployment_data.zip \
            mode=0664"
    ```

### Get Mirror Manager onto the instance

1. Get Mirror Manager

    ```bash
    ## download mirrormgr
    ansible localhost \
        -m get_url \
        -a "url=https://support.sas.com/installation/viya/34/sas-mirror-manager/lax/mirrormgr-linux.tgz \
            dest=./mirrormgr-linux.tgz  \
            mode=0664"
    ## extract it
    tar -xvf mirrormgr-linux.tgz mirrormgr
    ```

### Download the mirror

1. Create the mirror

    ```bash
    sudo mkdir -p /opt/viyamirror
    sudo chmod 777 /opt/viyamirror
    ./mirrormgr mirror \
          --deployment-data ./SAS_Viya_deployment_data.zip \
          --path /opt/viyamirror \
          --platform x64-redhat-linux-6 \
          --latest
    ```

### Get the Orchestration CLI

1. Get the Orchestration CLI onto the instance

    ```bash
    #get the orchestration tool.
    ansible localhost \
        -m get_url \
        -a "url=https://support.sas.com/installation/viya/34/sas-orchestration-cli/lax/sas-orchestration-linux.tgz \
            dest=./sas-orchestration-linux.tgz  \
            mode=0644"
    # unpack
    tar xvf sas-orchestration-linux.tgz
    ```

### Build your playbook

1. Create the playbook

    ```bash
    ## build the playbook
    ./sas-orchestration build \
      --input ./SAS_Viya_deployment_data.zip \
      --repository-warehouse file:///opt/viyamirror/ \
      --platform redhat
    ```

1. Explode the playbook

    ```bash
    tar xvf SAS_Viya_playbook.tgz
    ```

### Perform the pre-reqs with VIRK

1. Execute the VIRK pre-req playbook

    ```bash
    ## get VIRK
    cd ~/sas_viya_playbook/
    GIT_REPO=https://github.com/sassoftware/virk.git
    ## I'm using the dev branch because the main 3.4 branch does not work with the latest Ansible.
    BRANCH_TO_USE=viya-3.4-dev
    git clone $GIT_REPO --branch $BRANCH_TO_USE

    ## now execute VIRK with some override to quickly stage the machine
    ansible-playbook virk/playbooks/pre-install-playbook/va_pre_install_playbook.yml \
        --skip-tags skipmemfail,skipcoresfail,skipstoragefail,skipnicssfail,bandwidth \
        -e 'yum_cache_yn=1' \
        -e 'use_pause=no' \
        -e '{"custom_group_list": { "group": "sas" , "gid":"10001" } }' \
        -e '{"custom_user_list": [ { "name": "cas" , "uid":"10002", "group":"sas" , "groups":"sas" } , { "name": "sas" , "uid":"10001", "group":"sas" , "groups":"sas" } ] }'
    ```

## Setting a very static hostname and IP at the linux level

### Change the hostname

1. First, choose a new name for the server. This name will have to stay forever, so make sure you like it.

    ```bash
    ## what's the new hostname you chose?
    NEW_HOSTNAME=portableviya.sas
    ```

1. Get the GEL playbook that helps set a new hostname:

    ```bash
    ## get the playbook down
    ansible localhost \
        -m get_url \
        -a "dest=./gel.set.hostname.yml \
        url=https://gitlab.sas.com/cloudup/viya-gel-training-materials/raw/master/18w30/gel.example.playbooks/gel.set.hostname.yml \
        mode=640 \
        force=yes \
        backup=yes"
    ```

1. Now change the hostname to the new one:

    ```bash
    ###
    ansible-playbook gel.set.hostname.yml -e "new_hostname=$NEW_HOSTNAME"  --diff
    ```

### Associate your hostname with the 127.0.0.1 ip

1. Then, we want to associate the hostname with the ip 127.0.0.1:

    ```bash
    ## insert the new hostname right after 127.0.0.1 in /etc/hosts
    ansible localhost \
       -m replace \
       -b \
       -a "dest=/etc/hosts \
            regexp='^127\.0\.0\.1[ \t]+localhost' \
            replace=\"127.0.0.1 $NEW_HOSTNAME localhost\" \
            backup=yes "  --diff
    ```

### Reboot and check

1. At this point, reboot your server. After the reboot, confirm that the following 3 commands give the same output:

    ```bash
    hostname
    hostname -f
    hostname -A
    ```

If they don't, do not proceed. They have to return the same thing.

## Deploy OpenLDAP

1. Now that the hostname is static, let's install OpenLDAP on it:
1. Get the OpenLDAP playbook

    ```bash
    cd ~
    git clone https://gitlab.sas.com/canepg/OpenLDAP.git -b master
    ```

1. Deploy OpenLDAP

    ```bash
    cd ~/OpenLDAP/
    ansible-playbook gel.openldapsetup.yml -e 'use_pause=no'
    ```

1. Copy the generated sitedefault to the right location in the playbook:

    ```bash
    cp ./sitedefault.yml  ~/sas_viya_playbook/roles/consul/files/sitedefault.yml
    ```

## Edit the deployTarget reference in your inventory

1. this command will update your inventory

    ```bash
    ansible localhost \
        -m lineinfile \
        -a "dest=~/sas_viya_playbook/inventory.ini\
            regexp='^deployTarget\ ansible' \
            line='deployTarget ansible_connection=local consul_bind_adapter=lo self_deployment_ipv4_override=127.0.0.1 internal_deployment_ipv4_override=127.0.0.1' \
            backup=yes \
            " \
            --diff
    ```

## Kick off the deployment

1. If you are using Ansible 2.7, update your vars.yml to allow it:

    ```bash
    cd ~/sas_viya_playbook/
    ansible localhost \
        -m lineinfile \
        -a "dest=~/sas_viya_playbook/vars.yml \
        regexp='MAXIMUM_RECOMMENDED_ANSIBLE_VERSION' \ line='MAXIMUM_RECOMMENDED_ANSIBLE_VERSION: 2.7'  \
        backup=yes" --diff
    ```

1. Now you can kick off the deployment:

    ```bash
    cd ~/sas_viya_playbook/
    time ansible-playbook site.yml
    ```
