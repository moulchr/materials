# How to use it

1. Log in to the Ansible Controller, as the same account that was used for the deployment
1. dstat need to be deployed on each hosts in your environment:
    ```
    ansible sas-all -m yum -a "name=dstat state=present" -b
    ```

1. Disable the Viya "all-services" service on all machines. A quick way of doing so is to execute:

    ```
    ansible sas-all -m service -a "name=sas-viya-all-services.service enabled=no" -b
    ```
1. Copy the 3 files (gel.viya33_start.yml, gel.viya33_stop.yml, gel.startStopMicroServices.sh) in your sas-viya-playbook directory.
  1. The gel.viya33_stop.yml and gel.viya33_stop.yml Ansible playbooks use the inventory.ini file to execute commands on each hosts.

1. Optional: add the following lines to the end of your ansible.cfg:

    ```
    callback_whitelist = profile_tasks
    [callback_profile_tasks ]
    task_output_limit = 20
    sort_order = descending
    ```
1. To stop all the services, you can run:
    ```
    ansible-playbook gel.viya33_stop.yml
    ```
1. To start all the services, you can run:
    ```
    ansible-playbook gel.viya33_start.yml
    ```

# Considerations and future improvements
Depending how you start previously your environment, you could have issues because of existing registered services in the SAS Configuration Server (Consul).

I recommend you to first stop your environment as you did before, without using the GEL Ansible startup/shutdown scripts, and then start to use them to manage your environment startup/shutdown.
If you will have issues, you will need to clean up the SAS Configuration Server.

One of the major issue I had was when a mix of systemctl (systemd) and service (sysV) commands were used to manage the Viya services, then it is not easy to stop gracefully all services in the environment. Some of the services will stay registered against the SAS Configuration Server. If you have this kind of issues, I can provide you with a script and instructions to clean up your environment before you will be able to use the GEL Ansible startup/shutdown scripts to manage startup/shutdown in your environment.
