#!/bin/bash

# this file will completely wipe a collection and re-install.
# this may take a long time

# the status file.
STATUSFILE=/var/www/html/status/status.txt

# If EPEL is not defined:
if [ ! -f "/etc/yum.repos.d/epel.repo" ]; then
    # install EPEL

    ## find out which rhel (6 or 7)
    if   grep -q -i "release 6" /etc/redhat-release ; then
      majversion=6
    elif grep -q -i "release 7" /etc/redhat-release ; then
      majversion=7
    else
      echo "Running neither RHEL6.x nor RHEL 7.x "
    fi

    ## install epel
    echo "`date +"%Y-%m-%d_%H-%M-%S"`: Installing EPEL" | sudo tee -a $STATUSFILE
    sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-$majversion.noarch.rpm
    echo "`date +"%Y-%m-%d_%H-%M-%S"`: EPEL installed" | sudo tee -a $STATUSFILE
fi


# If ansible is not yet installed, then do it.
if [ ! -f "/usr/bin/ansible" ]; then
    # install Ansible & other packages

    ## this is the old way. I need a specific ansible version:
    #sudo yum install -y ansible unzip git mlocate python-passlib

    echo "`date +"%Y-%m-%d_%H-%M-%S"`: Installing Ansible" | sudo tee -a $STATUSFILE
    #this is the new way of getting ansible
    sudo yum install -y python python-setuptools python-devel openssl-devel python-pip gcc
    sudo yum install -y gcc automake openssl-devel python-devel libffi-devel python-crypto python-paramiko python-keyczar python-setuptools python-pip python-six python-pip python-virtualenv
    ## use pip instead of Yum, to install a specific ansible version
    sudo pip install --upgrade pip
    #sudo pip install 'ansible==2.3.1.0'
    sudo pip install ansible

    ansible --version
    echo "`date +"%Y-%m-%d_%H-%M-%S"`: Ansible Installed" | sudo tee -a $STATUSFILE
    ANSVER=`ansible --version | head -n 1`
    echo "`date +"%Y-%m-%d_%H-%M-%S"`: Ansible Version: $ANSVER" | sudo tee -a $STATUSFILE
fi







 ansible all -m shell -b -a 'yum erase \"sas-*\" -y '
 ansible all -m shell -b -a 'yum-complete-transaction --cleanup-only'
 ansible all -m shell -b -a 'rm -rf /etc/yum.repos.d/sas*.repo'
 ansible all -m shell -b -a 'yum clean all -y'
 ansible all -m shell -b -a 'rm -rf /var/cache/yum'
 ansible all -m shell -b -a 'rm -rf /opt/sas/viya*'
 ansible all -m shell -b -a 'yum repolist'
