SSL Configure Read Me

1. ssl_studio.yml will copy a supplied JKS keystore file to the SAS Studio machine and configure SAS Studio for SSL.

2. ssl_cal.yml will will copy a supplied .key and .crt file to the CAS Controller machine configure CAS Monitor for SSL.
   Currently this only supports pushing the certificate files to the CAS Controller.  In the future certificates may be needed on the Worker Nodes.

   Both playbooks share a common variables file:  ssl_vars.yml

   Place customer supplied certificates in a subdirectory beneath the playbook directory named ssl_files.  Certificate files should be named according to the host
   they identify.  For example, a cert for the cas controller on machine casc.abc.com would be named as cas.abc.com.crt.

   NOTE: for CAS, which uses "Apache style" pem encoded certificate and key files (as opposed to Java apps which use JKS keystore certificate archives),
      the file containing the server's identity certificate should also contain any intermediary CA certs. This reduces the burden on SSL clients 
      when validating the server's identity as they need access only to the Trusted ROOT CA's public certificate.

   When CAS Monitor is successfully configured for SSL, you should see a message similar to the following in the log for the CAS Controller machine:

	2017-02-02T17:13:16,197 INFO  [00000003] cas local MAIN NoUser [cashttp.c:1308] - HTTP server listening on HTTPS port 8777.


3. ssl_off.yml will undo the SSL configuration for either CAS Monitor or SAS Studio.  Execute with task specific tags to control which is being undone:  
   --tags ssloff_studio
   --tags ssloff_cas
   
