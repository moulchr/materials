sed -i -e "s/present: no/present: yes/g" ./gel.demo-directory-list.yml
ansible-playbook gel.demo-directories.yml "$@"