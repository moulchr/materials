sed -i -e "s/present: no/present: yes/g" ./gel.demo-user-list.yml
sed -i -e "s/present: no/present: yes/g" ./gel.demo-group-list.yml
ansible-playbook gel.demo-LDAP-users-and-groups.yml "$@"