sed -i -e "s/present: yes/present: no/g" ./gel.demo-user-list.yml
sed -i -e "s/present: yes/present: no/g" ./gel.demo-group-list.yml
ansible-playbook gel.demo-LDAP-users-and-groups.yml "$@"
