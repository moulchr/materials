#!/bin/sh

## add gitlab to the /etc/hosts, if not already there. 
if   grep -q -i "gitlab.sas.com" /etc/hosts ; then
  echo "gitlab already in /etc/hosts. skipping"
else
  echo "adding gitlab to /etc/hosts"
  echo '10.24.8.146 gitlab.sas.com' | sudo tee -a /etc/hosts
fi
