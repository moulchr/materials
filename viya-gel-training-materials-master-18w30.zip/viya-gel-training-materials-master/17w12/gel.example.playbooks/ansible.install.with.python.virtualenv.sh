#!/bin/bash

# first parameter is the desired ansible version
ANSIBLEVERSION=$1

if [[ -n "$ANSIBLEVERSION" ]]; then
    echo "You want to install Ansible version $ANSIBLEVERSION"
else
    ANSIBLEVERSION='2.2.1.0'
	echo "You did not specify any Ansible version"
	echo "Defaulting to $ANSIBLEVERSION"
fi

# name of virtual env
VIRTNAME="ansible-$ANSIBLEVERSION"
echo "the name of the python virtual env for ansible is $VIRTNAME"
# location of virtual env
PYTHONVIRTENV=python_virtal_env


# If EPEL is not defined: 
if [ ! -f "/etc/yum.repos.d/epel.repo" ]; then
    ## find out which rhel (6 or 7)
    if   grep -q -i "release 6" /etc/redhat-release ; then
      majversion=6
    elif grep -q -i "release 7" /etc/redhat-release ; then
      majversion=7
    else
      echo "Running neither RHEL6.x nor RHEL 7.x "
    fi

    ## install epel
    sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-$majversion.noarch.rpm
fi


# install required YUM packages
sudo yum install -y gcc automake openssl-devel python-devel libffi-devel python-crypto python-paramiko python-keyczar python-setuptools python-pip python-six python-pip python-virtualenv
# create directories in home folder
mkdir -p ~/$PYTHONVIRTENV && cd ~/$PYTHONVIRTENV
# create virtual env
virtualenv $VIRTNAME
# activate virtual env
source ~/$PYTHONVIRTENV/$VIRTNAME/bin/activate
# install Ansible in virtual env
pip install ansible==$ANSIBLEVERSION

echo "source ~/$PYTHONVIRTENV/$VIRTNAME/bin/activate" >> ~/.bashrc

echo "version of ansible installed:"
ansible --version