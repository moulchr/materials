#!/bin/bash


POOLFILE=/opt/sas/viya/config/etc/sasdatasvrc/postgres/pgpool0/pool.cdf

if   grep -q -i "node0=unhealthy" $POOLFILE ; then
  echo "Your postgres node0 is unhealthy. "
  # First, stop the postgres services
  echo "We'll first stop the postgres-related services "
  /etc/init.d/sas-viya-sasdatasvrc-postgres stop
  /etc/init.d/sas-viya-sasdatasvrc-postgres-node0-ct-pg_hba stop
  /etc/init.d/sas-viya-sasdatasvrc-postgres-node0-ct-postgresql  stop
  /etc/init.d/sas-viya-sasdatasvrc-postgres-pgpool0-ct-pcp  stop
  /etc/init.d/sas-viya-sasdatasvrc-postgres-pgpool0-ct-pgpool stop
  /etc/init.d/sas-viya-sasdatasvrc-postgres-pgpool0-ct-pool_hba stop
  
  echo "Now, we'll delete the log files in /var/log/sas/viya/sasdatasvrc/postgres/pgpool0, because they can cause issues too."
  rm -rf /var/log/sas/viya/sasdatasvrc/postgres/pgpool0/*

  echo "Now, we'll change the file from unhealthy to healthy."
  echo "File Before:"
  cat $POOLFILE
  sed -ibak -e "s/node0\=unhealthy/node0\=healthy/g" $POOLFILE
  echo "File After:"
  cat $POOLFILE

  echo "Now we restart the stopped services:"
  /etc/init.d/sas-viya-sasdatasvrc-postgres start
  /etc/init.d/sas-viya-sasdatasvrc-postgres-node0-ct-pg_hba start
  /etc/init.d/sas-viya-sasdatasvrc-postgres-node0-ct-postgresql  start
  /etc/init.d/sas-viya-sasdatasvrc-postgres-pgpool0-ct-pcp  start
  /etc/init.d/sas-viya-sasdatasvrc-postgres-pgpool0-ct-pgpool start
  /etc/init.d/sas-viya-sasdatasvrc-postgres-pgpool0-ct-pool_hba start
  
elif grep -q -i "node0=healthy" $POOLFILE ; then
  echo "Your postgres node0 is healthy. We are exiting now"
  exit
else
  echo "Apparently, neither healthy nor unhealthy"
  echo "showing you the file content and then exiting"
  cat $POOLFILE
  exit
fi

