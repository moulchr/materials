This Git repository contains materials related to Viya GEL Knowledge Transfer

[Link to the 16w20 materials](16w20)

[Link to the 17w12 materials](17w12)

Please contact Erwan Granger for any questions related to this content. 